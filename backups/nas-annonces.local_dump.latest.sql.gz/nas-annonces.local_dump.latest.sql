-- MySQL dump 10.13  Distrib 5.5.39, for Win32 (x86)
--
-- Host: localhost    Database: symfony
-- ------------------------------------------------------
-- Server version	5.6.12-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `advert_category`
--

DROP TABLE IF EXISTS `advert_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advert_category` (
  `advert_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`advert_id`,`category_id`),
  KEY `IDX_84EEA340D07ECCB6` (`advert_id`),
  KEY `IDX_84EEA34012469DE2` (`category_id`),
  CONSTRAINT `FK_84EEA34012469DE2` FOREIGN KEY (`category_id`) REFERENCES `nas_category` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_84EEA340D07ECCB6` FOREIGN KEY (`advert_id`) REFERENCES `nas_advert` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `advert_category`
--

LOCK TABLES `advert_category` WRITE;
/*!40000 ALTER TABLE `advert_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `advert_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `advertskill`
--

DROP TABLE IF EXISTS `advertskill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advertskill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `advert_id` int(11) NOT NULL,
  `skill_id` int(11) NOT NULL,
  `level` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_D6575F2D07ECCB6` (`advert_id`),
  KEY `IDX_D6575F25585C142` (`skill_id`),
  CONSTRAINT `FK_D6575F25585C142` FOREIGN KEY (`skill_id`) REFERENCES `nas_skill` (`id`),
  CONSTRAINT `FK_D6575F2D07ECCB6` FOREIGN KEY (`advert_id`) REFERENCES `nas_advert` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `advertskill`
--

LOCK TABLES `advertskill` WRITE;
/*!40000 ALTER TABLE `advertskill` DISABLE KEYS */;
INSERT INTO `advertskill` VALUES (1,22,1,'Expert'),(2,22,2,'Expert'),(3,22,3,'Expert'),(4,22,4,'Expert'),(5,22,5,'Expert'),(6,22,6,'Expert'),(7,22,7,'Expert'),(8,23,1,'Expert'),(9,23,2,'Expert'),(10,23,3,'Expert'),(11,23,4,'Expert'),(12,23,5,'Expert'),(13,23,6,'Expert'),(14,23,7,'Expert'),(15,24,1,'Expert'),(16,24,2,'Expert'),(17,24,3,'Expert'),(18,24,4,'Expert'),(19,24,5,'Expert'),(20,24,6,'Expert'),(21,24,7,'Expert'),(22,25,1,'Expert'),(23,25,2,'Expert'),(24,25,3,'Expert'),(25,25,4,'Expert'),(26,25,5,'Expert'),(27,25,6,'Expert'),(28,25,7,'Expert'),(29,26,1,'Expert'),(30,26,2,'Expert'),(31,26,3,'Expert'),(32,26,4,'Expert'),(33,26,5,'Expert'),(34,26,6,'Expert'),(35,26,7,'Expert'),(36,27,1,'Expert'),(37,27,2,'Expert'),(38,27,3,'Expert'),(39,27,4,'Expert'),(40,27,5,'Expert'),(41,27,6,'Expert'),(42,27,7,'Expert'),(43,36,1,'Expert'),(44,36,2,'Expert'),(45,36,3,'Expert'),(46,36,4,'Expert'),(47,36,5,'Expert'),(48,36,6,'Expert'),(49,36,7,'Expert');
/*!40000 ALTER TABLE `advertskill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nas_advert`
--

DROP TABLE IF EXISTS `nas_advert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nas_advert` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `author` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `published` tinyint(1) NOT NULL,
  `image_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_75CD93D73DA5256D` (`image_id`),
  CONSTRAINT `FK_75CD93D73DA5256D` FOREIGN KEY (`image_id`) REFERENCES `nas_image` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nas_advert`
--

LOCK TABLES `nas_advert` WRITE;
/*!40000 ALTER TABLE `nas_advert` DISABLE KEYS */;
INSERT INTO `nas_advert` VALUES (22,'2014-11-21 22:19:20','Recherche développeur Symfony2.','Alexandre','Nous recherchons un développeur Symfony2 débutant sur Lyon. Blabla…',1,12),(23,'2014-11-22 00:28:23','Recherche développeur Symfony2.','Alexandre','Nous recherchons un développeur Symfony2 débutant sur Lyon. Blabla…',1,13),(24,'2014-11-22 00:28:32','Recherche développeur Symfony2.','Alexandre','Nous recherchons un développeur Symfony2 débutant sur Lyon. Blabla…',1,14),(25,'2014-11-22 00:28:35','Recherche développeur Symfony2.','Alexandre','Nous recherchons un développeur Symfony2 débutant sur Lyon. Blabla…',1,15),(26,'2014-11-22 00:28:41','Recherche développeur Symfony2.','Alexandre','Nous recherchons un développeur Symfony2 débutant sur Lyon. Blabla…',1,16),(27,'2014-11-26 16:39:47','Recherche développeur Symfony2.','Alexandre','Nous recherchons un développeur Symfony2 débutant sur Paris. Blabla…',1,17),(36,'2014-11-26 17:01:54','Recherche développeur Android et IOS','Alexandre','Nous recherchons un développeur ANDROID et IOS débutant sur Rennes. Blabla…',1,22);
/*!40000 ALTER TABLE `nas_advert` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nas_application`
--

DROP TABLE IF EXISTS `nas_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nas_application` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `advert_id` int(11) NOT NULL,
  `author` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_EF418934D07ECCB6` (`advert_id`),
  CONSTRAINT `FK_EF418934D07ECCB6` FOREIGN KEY (`advert_id`) REFERENCES `nas_advert` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nas_application`
--

LOCK TABLES `nas_application` WRITE;
/*!40000 ALTER TABLE `nas_application` DISABLE KEYS */;
INSERT INTO `nas_application` VALUES (21,22,'Marine','J\'ai toutes les qualités requises.','2014-11-21 22:19:20'),(22,22,'Pierre','Je suis très motivé.','2014-11-21 22:19:20'),(23,23,'Marine','J\'ai toutes les qualités requises.','2014-11-22 00:28:23'),(24,23,'Pierre','Je suis très motivé.','2014-11-22 00:28:23'),(25,24,'Marine','J\'ai toutes les qualités requises.','2014-11-22 00:28:32'),(26,24,'Pierre','Je suis très motivé.','2014-11-22 00:28:32'),(27,25,'Marine','J\'ai toutes les qualités requises.','2014-11-22 00:28:35'),(28,25,'Pierre','Je suis très motivé.','2014-11-22 00:28:35'),(29,26,'Marine','J\'ai toutes les qualités requises.','2014-11-22 00:28:41'),(30,26,'Pierre','Je suis très motivé.','2014-11-22 00:28:41'),(31,27,'Marine','J\'ai toutes les qualités requises.','2014-11-26 16:39:47'),(32,27,'Pierre','Je suis très motivé.','2014-11-26 16:39:47'),(33,36,'Marine','J\'ai toutes les qualités requises.','2014-11-26 17:01:54'),(34,36,'Pierre','Je suis très motivé.','2014-11-26 17:01:54');
/*!40000 ALTER TABLE `nas_application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nas_category`
--

DROP TABLE IF EXISTS `nas_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nas_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nas_category`
--

LOCK TABLES `nas_category` WRITE;
/*!40000 ALTER TABLE `nas_category` DISABLE KEYS */;
INSERT INTO `nas_category` VALUES (6,'Développement web'),(7,'Développement mobile'),(8,'Graphisme'),(9,'Intégration'),(10,'Réseau');
/*!40000 ALTER TABLE `nas_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nas_image`
--

DROP TABLE IF EXISTS `nas_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nas_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alt` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nas_image`
--

LOCK TABLES `nas_image` WRITE;
/*!40000 ALTER TABLE `nas_image` DISABLE KEYS */;
INSERT INTO `nas_image` VALUES (12,'http://sdz-upload.s3.amazonaws.com/prod/upload/job-de-reve.jpg','Job de rêve'),(13,'http://sdz-upload.s3.amazonaws.com/prod/upload/job-de-reve.jpg','Job de rêve'),(14,'http://sdz-upload.s3.amazonaws.com/prod/upload/job-de-reve.jpg','Job de rêve'),(15,'http://sdz-upload.s3.amazonaws.com/prod/upload/job-de-reve.jpg','Job de rêve'),(16,'http://sdz-upload.s3.amazonaws.com/prod/upload/job-de-reve.jpg','Job de rêve'),(17,'http://sdz-upload.s3.amazonaws.com/prod/upload/job-de-reve.jpg','Job de rêve'),(22,'http://sdz-upload.s3.amazonaws.com/prod/upload/job-de-reve.jpg','Job de rêve');
/*!40000 ALTER TABLE `nas_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nas_skill`
--

DROP TABLE IF EXISTS `nas_skill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nas_skill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nas_skill`
--

LOCK TABLES `nas_skill` WRITE;
/*!40000 ALTER TABLE `nas_skill` DISABLE KEYS */;
INSERT INTO `nas_skill` VALUES (1,'PHP'),(2,'Symfony2'),(3,'C++'),(4,'Java'),(5,'Photoshop'),(6,'Blender'),(7,'Bloc-note');
/*!40000 ALTER TABLE `nas_skill` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-11-26 19:19:38
